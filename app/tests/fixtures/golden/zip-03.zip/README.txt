Sharp Viewer - Android assets
Generated 2026-10-17T11:03:53.825Z

Drawable "wide" - 200x100 dp, from a 4000x1000 px source

res/drawable-mdpi/wide.png: 200x100 px (1x)
res/drawable-hdpi/wide.png: 300x150 px (1.5x)
res/drawable-xhdpi/wide.png: 400x200 px (2x)
res/drawable-xxhdpi/wide.png: 600x300 px (3x)
res/drawable-xxxhdpi/wide.png: 800x400 px (4x)

No warnings: the source has enough pixels for every size.

Copy the res/ folders into your module's src/main/res/.