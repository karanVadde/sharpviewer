Sharp Viewer - Android assets
Generated 2026-10-17T11:03:48.555Z

Drawable "banner" - 360 dp, from a 1600x1200 px source

res/drawable-mdpi/banner.png: 360x270 px (1x)
res/drawable-hdpi/banner.png: 540x405 px (1.5x)
res/drawable-xhdpi/banner.png: 720x540 px (2x)
res/drawable-xxhdpi/banner.png: 1080x810 px (3x)
res/drawable-xxxhdpi/banner.png: 1440x1080 px (4x)

No warnings: the source has enough pixels for every size.

Copy the res/ folders into your module's src/main/res/.