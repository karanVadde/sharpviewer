Sharp Viewer - Android assets
Generated 2026-10-17T11:03:50.551Z

Drawable "hero" - 360x200 dp, from a 320x240 px source

res/drawable-mdpi/hero.webp: 360x200 px (1x) - UPSCALED ×1.1
res/drawable-xxxhdpi/hero.webp: 1440x800 px (4x) - UPSCALED ×4.5
res/drawable-nodpi/hero.webp: 360x200 px (density-independent, drawn 1:1)

WARNINGS
- mdpi (360x200 px) is upscaled ×1.1 from the 320x240 px source.
- xxxhdpi (1440x800 px) is upscaled ×4.5 from the 320x240 px source.

Copy the res/ folders into your module's src/main/res/.