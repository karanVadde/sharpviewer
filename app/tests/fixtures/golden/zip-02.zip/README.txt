Sharp Viewer - Android assets
Generated 2026-10-17T11:03:52.823Z

Launcher icon "ic_launcher" - adaptive (API 26+) + legacy + Play Store, background #1f2933

res/mipmap-mdpi/: ic_launcher.png 48x48 (legacy 48 dp), ic_launcher_foreground.png + _background.png 108x108 (adaptive 108 dp)
res/mipmap-hdpi/: ic_launcher.png 72x72 (legacy 48 dp), ic_launcher_foreground.png + _background.png 162x162 (adaptive 108 dp)
res/mipmap-xhdpi/: ic_launcher.png 96x96 (legacy 48 dp), ic_launcher_foreground.png + _background.png 216x216 (adaptive 108 dp)
res/mipmap-xxhdpi/: ic_launcher.png 144x144 (legacy 48 dp), ic_launcher_foreground.png + _background.png 324x324 (adaptive 108 dp)
res/mipmap-xxxhdpi/: ic_launcher.png 192x192 (legacy 48 dp), ic_launcher_foreground.png + _background.png 432x432 (adaptive 108 dp)
res/mipmap-anydpi-v26/ic_launcher.xml + ic_launcher_round.xml: adaptive icon definitions
playstore/ic_launcher-512.png: Play Store listing icon (512x512, no transparency)

Safe zone: the image is fitted into the 66 dp circle's square of the 108 dp canvas; launchers mask the outer 18 dp.

No warnings: the source has enough pixels for every size.

Copy the res/ folders into your module's src/main/res/.