Sharp Viewer - Android assets
Generated 2026-10-17T11:03:55.065Z

Drawable "pair" - 360 dp, from a 1080x1080 px source

res/drawable-mdpi/pair.png: 360x360 px (1x)
res/drawable-xhdpi/pair.png: 720x720 px (2x)

No warnings: the source has enough pixels for every size.

Copy the res/ folders into your module's src/main/res/.